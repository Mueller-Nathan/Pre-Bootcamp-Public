#Nathan Mueller - Basic Functions 2
#Python Stack

#1
def countdown(x):
    for x in range(x, 0, -1):
        print(x)

#2
def print_and_return(arr):
    print(arr[1])
    return arr[3]

#3
def first_plus_length(arr):
    return arr[0] + len(arr)
    
#4
def values_greater_than_second(arr):     
    new_arr = []
    if len(arr) <= 1:
        return False
    for x in arr:
        if arr[x] > arr[1]:
            new_arr.append(arr[x])
            print(len(new_arr))
            return new_arr

#5
def this_length_that_value(size, value):
    new_arr = []
    for x in range(0, size):
        new_arr.append(value)
        return new_arr

#Was incorrect in my attempts at problems #4 and #5


