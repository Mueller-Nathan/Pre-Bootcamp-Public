from django.apps import AppConfig


class BooksappConfig(AppConfig):
    name = 'booksApp'
