from django.apps import AppConfig


class DojoninjasAppConfig(AppConfig):
    name = 'dojoNinjas_app'
