from django.db import models

class Dojo(models.Model):

    name = models.CharField(max_length=225)
    city = models.CharField(max_length=225)
    state = models.CharField(max_length=225)

    description = models.TextField(default="old dojo")

    def __str__(self):
        return '{}'.format(self.name)

class Ninja(models.Model):

    dojo = models.ForeignKey(Dojo,
                            on_delete=models.CASCADE,
                            related_name='ninjas')
    first_name = models.CharField(max_length=45)
    last_name = models.CharField(max_length=45)

    def __str__(self):
        return '{} {}'.format(self.first_name, self.last_name)
