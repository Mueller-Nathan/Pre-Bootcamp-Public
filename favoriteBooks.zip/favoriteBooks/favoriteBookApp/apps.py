from django.apps import AppConfig


class FavoritebookappConfig(AppConfig):
    name = 'favoriteBookApp'
