from django.shortcuts import render, HttpResponse

def new(request):
    return HttpResponse("placeholder to display a new form to create a new blog")
