from django.apps import AppConfig


class LogregAppConfig(AppConfig):
    name = 'logReg_app'
