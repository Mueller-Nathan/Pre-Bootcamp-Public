from django.db import models

class TvManager(models.Manager):
    def basic_validator(self, post_data):
        errors = {}
        if len(post_data['title']) < 2:
            errors['title'] = "Title should be at least 2 characters."
        if len(post_data['network']) < 3:
            errors['network'] = "Network should be at least 3 characters."
        if len(post_data['description']) < 10:
            errors['description'] = "Description should be at least 10 characters."
        return errors

# Create your models here.
class Show(models.Model):
    title = models.CharField(max_length=45)
    network = models.CharField(max_length=45)
    release_date = models.DateTimeField()
    description = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = TvManager()

#post_data == request.POST