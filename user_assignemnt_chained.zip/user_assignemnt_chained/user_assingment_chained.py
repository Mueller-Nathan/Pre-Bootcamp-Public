class User:
    def __init__(self, name, email):
        self.name = name
        self.email = email
        self.account = 100

    def make_deposit(self, amount):
        self.account += amount
        return self

    def make_withdrawal(self, amount):
        self.account -= amount
        return self

    def display_user_balance(self):
        print(self.account)
        return self

    def transfer_money(self, other_user, amount):
        other_user.make_deposit(amount)
        self.make_withdrawal(amount)


nate = User("Nate", "nate@mail.com")
tim = User("Tim", "tim@mail.com")
olie = User("Olie", "olie@mail.com")

# Have the first user make 3 deposits and 1 withdrawal and then display their balance

nate.make_deposit(20).make_deposit(90).make_deposit(120).make_withdrawal(50).display_user_balance()


# Have the second user make 2 deposits and 2 withdrawals and then display their balance

tim.make_deposit(100).make_deposit(100).make_withdrawal(50).make_withdrawal(50).display_user_balance()


# Have the third user make 1 deposits and 3 withdrawals and then display their balance 

olie.make_deposit(100).make_withdrawal(50).make_withdrawal(50).make_withdrawal(100).display_user_balance()


# Add a transfer_money method; have the first user transfer money to the third user and then print both users' balances

nate.transfer_money(olie, 150)
nate.display_user_balance()
olie.display_user_balance()

